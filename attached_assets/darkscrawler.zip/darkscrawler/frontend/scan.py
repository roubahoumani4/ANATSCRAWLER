import os
import re
import pdfkit # type: ignore

# Function to run Lynis scan and generate report
def run_lynis_scan():
    # Run the Lynis scan
    scan_command = "sudo lynis audit system > lynis_scan_output.txt"
    os.system(scan_command)

    # Read the output of the scan
    with open("lynis_scan_output.txt", "r") as file:
        scan_output = file.read()

    # Clean the output: remove unreadable syntax and the word "Lynis"
    cleaned_output = clean_scan_output(scan_output)

    # Parse sections of the output for HTML generation
    sections = cleaned_output.split("[+] ")
    report_sections = {section.split("\n", 1)[0]: section.split("\n", 1)[1] for section in sections if "\n" in section}

    # Generate the HTML page
    generate_html_page(report_sections)

    # Generate the PDF report
    generate_pdf_report(report_sections)

def clean_scan_output(scan_output):
    # Remove escape sequences and unreadable syntax (e.g., [1;37m, ␛[0;36m)
    readable_output = re.sub(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])', '', scan_output)
    # Remove the word "Lynis"
    readable_output = readable_output.replace("Lynis", "")
    return readable_output

def generate_pdf_report(sections):
    # Path to save the PDF report
    report_path = "/home/rouba-houmani/ANAT_SECURITY_REPORT.pdf"

    # HTML structure with styling
    html_template = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ANAT SECURITY REPORT</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                color: #000000;
            }}
            header {{
                text-align: center;
                padding: 20px;
                background-color: #f4f4f4;
            }}
            h1 {{
                color: #333;
            }}
            main {{
                padding: 20px;
            }}
            table {{
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 20px;
            }}
            th, td {{
                border: 1px solid #000000;
                padding: 8px;
                text-align: left;
            }}
            th {{
                background-color: #333;
                color: #FFFFFF;
            }}
        </style>
    </head>
    <body>
        <header>
            <h1>ANAT SECURITY REPORT</h1>
        </header>
        <main>
    """
    for section_title, section_content in sections.items():
        html_template += f"""
        <section>
            <h2>{section_title}</h2>
            <table>
                <tr><th>Details</th></tr>
                <tr><td><pre>{section_content}</pre></td></tr>
            </table>
        </section>
        """

    html_template += """
        </main>
    </body>
    </html>
    """

    # Save the HTML content to a temporary file
    with open("temp_report.html", "w") as temp_file:
        temp_file.write(html_template)

    # Convert the HTML file to PDF
    pdfkit.from_file("temp_report.html", report_path)

    # Clean up the temporary HTML file
    os.remove("temp_report.html")

    print(f"PDF report saved at: {report_path}")

def generate_html_page(sections):
    # HTML structure with styling and a button to download the report
    html_template = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ANAT SECURITY REPORT</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                background-color: #1E1E2F;
                color: #EAEAEA;
                margin: 0;
                padding: 0;
            }}
            header {{
                background-color: #3C3C58;
                padding: 20px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }}
            header h1 {{
                color: #FFD700;
            }}
            button {{
                background-color: #FFD700;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                cursor: pointer;
                font-weight: bold;
            }}
            button:hover {{
                background-color: #FFC300;
            }}
            main {{
                padding: 20px;
            }}
            table {{
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 20px;
            }}
            th, td {{
                border: 1px solid #EAEAEA;
                padding: 8px;
                text-align: left;
            }}
            th {{
                background-color: #3C3C58;
            }}
        </style>
    </head>
    <body>
        <header>
            <h1>ANAT SECURITY REPORT</h1>
            <button onclick="downloadPDF()">Download Report as PDF</button>
        </header>
        <main>
    """
    for section_title, section_content in sections.items():
        html_template += f"""
        <section>
            <h2>{section_title}</h2>
            <table>
                <tr><th>Details</th></tr>
                <tr><td><pre>{section_content}</pre></td></tr>
            </table>
        </section>
        """

    html_template += """
        </main>
        <script>
            function downloadPDF() {{
                window.open('/home/rouba-houmani/ANAT_SECURITY_REPORT.pdf', '_blank');
            }}
        </script>
    </body>
    </html>
    """

    # Save the HTML file
    html_path = "/home/rouba-houmani/ANAT_SECURITY_REPORT.html"
    with open(html_path, "w") as file:
        file.write(html_template)

    print(f"HTML report saved at: {html_path}")

# Run the script
if __name__ == "__main__":
    print("Running Lynis scan and generating reports...")
    run_lynis_scan()

